CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nivel VARCHAR(50) NOT NULL DEFAULT 'utilizador'
);

-- Utilizador inicial de exemplo.
-- Altere imediatamente a palavra-passe após o primeiro acesso.
INSERT INTO usuarios(username, password, nivel)
VALUES ('admin', 'admin123', 'administrador')
ON DUPLICATE KEY UPDATE username = username;
