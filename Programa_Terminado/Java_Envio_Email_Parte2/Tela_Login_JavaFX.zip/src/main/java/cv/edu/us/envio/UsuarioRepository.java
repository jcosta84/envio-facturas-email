package cv.edu.us.envio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Repositório responsável pela autenticação dos utilizadores.
 *
 * Esta versão considera uma tabela "usuarios" com as colunas:
 * id, username, password e nivel.
 */
public final class UsuarioRepository {

    private final Database db;

    public UsuarioRepository(Database db) {
        this.db = db;
    }

    public Usuario autenticar(
            String username,
            String password
    ) throws SQLException {

        String sql = """
            SELECT id, username, nivel
            FROM usuarios
            WHERE username = ?
              AND password = ?
            LIMIT 1
            """;

        try (Connection conn = db.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username.trim());
            stmt.setString(2, password);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("nivel")
                    );
                }
            }
        }

        return null;
    }
}
