package cv.edu.us.envio;

/**
 * Representa um utilizador autenticado no sistema.
 */
public record Usuario(
        int id,
        String username,
        String nivel
) {
    public Usuario {
        username = username == null ? "" : username.trim();
        nivel = nivel == null ? "" : nivel.trim();
    }
}
