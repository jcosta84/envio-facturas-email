import re
import threading
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Dict, List, Optional

import customtkinter as ctk

from database.repositories import (
    AuditoriaRepository,
    CcRepository,
    ClienteRepository,
    ConfiguracaoRepository,
    RelatorioRepository,
    UsuarioRepository,
)
from models.entities import Cliente, RelatorioEnvio
from services.email_service import EmailService
from services.export_service import exportar_excel, exportar_pdf

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class MainView(ctk.CTk):
    BG = "#181A1D"
    SIDEBAR = "#111315"
    PANEL = "#24272A"
    PANEL_2 = "#2D3034"
    BORDER = "#3A3E43"
    ACTIVE = "#4B4F54"
    BLUE = "#4C8DFF"

    def __init__(self, config, db, usuario):
        super().__init__()
        self.config_service = config
        self.db = db
        self.usuario = usuario
        self.clientes = ClienteRepository(db)
        self.cc = CcRepository(db)
        self.conf = ConfiguracaoRepository(db)
        self.relatorios = RelatorioRepository(db)
        self.usuarios = UsuarioRepository(db)
        self.aud = AuditoriaRepository(db)
        self.email = EmailService(config)
        self.botao_ativo = None
        self.botoes_menu: Dict[str, ctk.CTkButton] = {}

        self.title("Gestão e Envio de E-mails")
        self.geometry("1280x760")
        self.minsize(1120, 700)
        self.configure(fg_color=self.BG)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)

        self._configurar_treeview()
        self._criar_estrutura()
        self._criar_menu()
        self._criar_status_bar()
        self.abrir_pagina("Início", self.pagina_inicio)

    def _configurar_treeview(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "Dark.Treeview",
            background="#202326",
            foreground="#FFFFFF",
            fieldbackground="#202326",
            borderwidth=0,
            rowheight=31,
            font=("Segoe UI", 10),
        )
        style.configure(
            "Dark.Treeview.Heading",
            background="#2B2E32",
            foreground="#FFFFFF",
            relief="flat",
            font=("Segoe UI", 10, "bold"),
        )
        style.map(
            "Dark.Treeview",
            background=[("selected", self.BLUE)],
            foreground=[("selected", "#FFFFFF")],
        )
        style.map("Dark.Treeview.Heading", background=[("active", "#363A3F")])

    def _criar_estrutura(self):
        self.sidebar = ctk.CTkFrame(self, width=245, corner_radius=0, fg_color=self.SIDEBAR)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)

        self.content = ctk.CTkFrame(self, corner_radius=0, fg_color=self.BG)
        self.content.grid(row=0, column=1, sticky="nsew")
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(0, weight=1)

        self.status_bar = ctk.CTkFrame(self, height=36, corner_radius=0, fg_color="#202225")
        self.status_bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        self.status_bar.grid_columnconfigure(1, weight=1)

    def _criar_menu(self):
        ctk.CTkLabel(
            self.sidebar,
            text=self.usuario.username,
            font=ctk.CTkFont(size=18, weight="bold"),
        ).pack(pady=(28, 0))
        ctk.CTkLabel(
            self.sidebar,
            text=self.usuario.nivel.upper(),
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(pady=(0, 24))

        itens = [
            ("Início", "⌂", self.pagina_inicio),
            ("Clientes", "♟", self.pagina_clientes),
            ("Consulta", "⌕", self.pagina_consulta),
            ("Enviar E-mails", "✉", self.pagina_envio),
            ("Corpo do E-mail", "⚙", self.pagina_corpo),
            ("Gerir CC", "♟", self.pagina_cc),
            ("Relatórios", "≡", self.pagina_relatorios),
        ]
        if self.usuario.is_admin:
            itens.append(("Utilizadores", "▢", self.pagina_usuarios))
        if self.usuario.is_gerente:
            itens.append(("Definições", "⚙", self.pagina_definicoes))

        for texto, icone, comando in itens:
            botao = ctk.CTkButton(
                self.sidebar,
                text="{}   {}".format(icone, texto),
                anchor="w",
                height=38,
                corner_radius=7,
                fg_color="#34373B",
                hover_color="#45494E",
                font=ctk.CTkFont(size=13, weight="bold"),
                command=lambda n=texto, c=comando: self.abrir_pagina(n, c),
            )
            botao.pack(fill="x", padx=18, pady=5)
            self.botoes_menu[texto] = botao

        ctk.CTkButton(
            self.sidebar,
            text="↪   Sair",
            anchor="w",
            height=38,
            fg_color="#34373B",
            hover_color="#45494E",
            command=self.destroy,
        ).pack(side="bottom", fill="x", padx=18, pady=(0, 18))
        ctk.CTkButton(
            self.sidebar,
            text="⏻   Terminar Sessão",
            anchor="w",
            height=38,
            fg_color="#34373B",
            hover_color="#45494E",
            command=self.terminar_sessao,
        ).pack(side="bottom", fill="x", padx=18, pady=5)
        ctk.CTkFrame(self.sidebar, height=2, fg_color="#34373B").pack(
            side="bottom", fill="x", padx=18, pady=(0, 12)
        )

    def _criar_status_bar(self):
        ctk.CTkLabel(
            self.status_bar,
            text="●  Ligação com a base de dados: OK",
            text_color="#FFFFFF",
            font=ctk.CTkFont(size=12, weight="bold"),
        ).grid(row=0, column=0, padx=18, pady=8, sticky="w")
        self.label_data_hora = ctk.CTkLabel(self.status_bar, text="")
        self.label_data_hora.grid(row=0, column=2, padx=18, pady=8, sticky="e")
        self._atualizar_relogio()

    def _atualizar_relogio(self):
        self.label_data_hora.configure(text=datetime.now().strftime("▣   %d/%m/%Y     ◷   %H:%M:%S"))
        self.after(1000, self._atualizar_relogio)

    def limpar(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def abrir_pagina(self, nome, comando):
        if self.botao_ativo is not None:
            self.botao_ativo.configure(fg_color="#34373B", border_width=0)
        botao = self.botoes_menu.get(nome)
        if botao is not None:
            botao.configure(fg_color=self.ACTIVE, border_width=3, border_color=self.BLUE)
            self.botao_ativo = botao
        comando()

    def pagina(self, titulo, scroll=True):
        self.limpar()
        if scroll:
            frame = ctk.CTkScrollableFrame(self.content, fg_color=self.BG)
        else:
            frame = ctk.CTkFrame(self.content, fg_color=self.BG)
        frame.grid(row=0, column=0, sticky="nsew", padx=26, pady=24)
        frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(frame, text=titulo, font=ctk.CTkFont(size=29, weight="bold")).grid(
            row=0, column=0, sticky="w", pady=(0, 18)
        )
        return frame

    def terminar_sessao(self):
        self.destroy()

    def _criar_tree(self, parent, colunas, widths=None, height=13):
        container = ctk.CTkFrame(parent, fg_color=self.PANEL, corner_radius=10)
        container.grid_columnconfigure(0, weight=1)
        container.grid_rowconfigure(0, weight=1)
        tree = ttk.Treeview(
            container,
            columns=colunas,
            show="headings",
            height=height,
            style="Dark.Treeview",
        )
        scroll_y = ttk.Scrollbar(container, orient="vertical", command=tree.yview)
        scroll_x = ttk.Scrollbar(container, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        for index, coluna in enumerate(colunas):
            tree.heading(coluna, text=coluna)
            largura = widths[index] if widths and index < len(widths) else 140
            tree.column(coluna, width=largura, minwidth=80, anchor="center")
        tree.grid(row=0, column=0, sticky="nsew", padx=(8, 0), pady=(8, 0))
        scroll_y.grid(row=0, column=1, sticky="ns", pady=(8, 0))
        scroll_x.grid(row=1, column=0, sticky="ew", padx=(8, 0), pady=(0, 8))
        return container, tree

    def _card(self, parent, column, icon, number, title, subtitle):
        card = ctk.CTkFrame(
            parent, height=155, corner_radius=12, fg_color="#292C2F",
            border_width=1, border_color="#383C40"
        )
        card.grid(row=0, column=column, sticky="nsew", padx=8, pady=5)
        card.grid_propagate(False)
        ctk.CTkLabel(card, text=icon, font=ctk.CTkFont(size=24)).pack(anchor="w", padx=18, pady=(14, 3))
        ctk.CTkLabel(card, text=str(number), font=ctk.CTkFont(size=30, weight="bold")).pack(anchor="w", padx=18)
        ctk.CTkLabel(card, text=title, font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=18)
        ctk.CTkLabel(card, text=subtitle, font=ctk.CTkFont(size=12)).pack(anchor="w", padx=18)

    def pagina_inicio(self):
        frame = self.pagina("Início")
        ctk.CTkLabel(
            frame,
            text="Bem-vindo(a) ao sistema de gestão de clientes e envio de e-mails.",
            font=ctk.CTkFont(size=15),
        ).grid(row=1, column=0, sticky="w", pady=(0, 12))
        try:
            clientes = list(self.clientes.listar())
            relatorios = list(self.relatorios.listar())
            cc = list(self.cc.listar())
        except Exception:
            clientes, relatorios, cc = [], [], []

        cards = ctk.CTkFrame(frame, fg_color="transparent")
        cards.grid(row=2, column=0, sticky="ew")
        for col in range(4):
            cards.grid_columnconfigure(col, weight=1)
        self._card(cards, 0, "♟", len(clientes), "Clientes", "Cadastrados")
        self._card(cards, 1, "✉", len(relatorios), "E-mails", "Enviados")
        self._card(cards, 2, "▥", len(relatorios), "Relatórios", "Registados")
        self._card(cards, 3, "♟♟", len(cc), "Destinatários CC", "Ativos")

        recente = ctk.CTkFrame(frame, fg_color=self.PANEL, corner_radius=12)
        recente.grid(row=3, column=0, sticky="ew", pady=(12, 8))
        recente.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(recente, text="Atividade recente", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, sticky="w", padx=18, pady=(14, 6))
        holder, tree = self._criar_tree(recente, ("Data/Hora", "Cliente", "E-mail", "Status", "Mensagem"), [145, 150, 210, 90, 300], 3)
        holder.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 10))
        for rel in relatorios[:5]:
            tree.insert("", "end", values=(rel.data_envio.strftime("%d/%m/%Y %H:%M"), rel.nome, rel.email, rel.status, rel.mensagem))

        acoes = ctk.CTkFrame(frame, fg_color=self.PANEL, corner_radius=12)
        acoes.grid(row=4, column=0, sticky="ew", pady=(8, 0))
        ctk.CTkLabel(acoes, text="Ações rápidas", font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=18, pady=(14, 8))
        linha = ctk.CTkFrame(acoes, fg_color="transparent")
        linha.pack(fill="x", padx=12, pady=(0, 16))
        for texto, pagina in [
            ("♟ Novo Cliente", self.pagina_clientes),
            ("✉ Enviar E-mails", self.pagina_envio),
            ("≡ Relatório", self.pagina_relatorios),
            ("⚙ Corpo do E-mail", self.pagina_corpo),
            ("♟ Gerir CC", self.pagina_cc),
        ]:
            ctk.CTkButton(linha, text=texto, height=72, fg_color=self.PANEL_2, hover_color="#3B3F44", command=pagina).pack(side="left", expand=True, fill="x", padx=6)

    def pagina_clientes(self):
        frame = self.pagina("Cadastro de Clientes")
        form = ctk.CTkFrame(frame, fg_color=self.PANEL, corner_radius=12)
        form.grid(row=1, column=0, sticky="ew")
        form.grid_columnconfigure(1, weight=1)
        labels = ["CIL", "Nome", "E-mail", "Arquivo anexo"]
        entradas = {}
        for row, label in enumerate(labels):
            ctk.CTkLabel(form, text=label, font=ctk.CTkFont(weight="bold")).grid(row=row, column=0, padx=18, pady=10, sticky="w")
            entrada = ctk.CTkEntry(form, height=38)
            entrada.grid(row=row, column=1, padx=18, pady=10, sticky="ew")
            entradas[label] = entrada

        def escolher():
            caminho = filedialog.askopenfilename(filetypes=[("PDF", "*.pdf"), ("Todos", "*.*")])
            if caminho:
                entradas["Arquivo anexo"].delete(0, "end")
                entradas["Arquivo anexo"].insert(0, Path(caminho).name)

        ctk.CTkButton(form, text="Selecionar PDF", width=130, command=escolher).grid(row=3, column=2, padx=(0, 18))

        def guardar():
            cliente = Cliente(
                entradas["CIL"].get().strip(),
                entradas["Nome"].get().strip(),
                entradas["E-mail"].get().strip(),
                entradas["Arquivo anexo"].get().strip(),
            )
            if not cliente.cil or not cliente.nome or not EMAIL_RE.match(cliente.email):
                messagebox.showwarning("Validação", "Preencha CIL, nome e um e-mail válido.")
                return
            try:
                self.clientes.inserir(cliente)
                self.aud.log(self.usuario.id, "INSERIR", "Clientes", "Cliente {} inserido.".format(cliente.cil))
                messagebox.showinfo("Sucesso", "Cliente guardado com sucesso.")
                for entrada in entradas.values():
                    entrada.delete(0, "end")
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        ctk.CTkButton(frame, text="Guardar", width=130, command=guardar).grid(row=2, column=0, sticky="e", pady=14)

    def pagina_consulta(self):
        frame = self.pagina("Consulta e CRUD de Clientes", scroll=False)
        busca = ctk.CTkEntry(frame, placeholder_text="Filtrar por CIL, nome ou e-mail", height=38)
        busca.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        holder, tree = self._criar_tree(frame, ("CIL", "Nome", "E-mail", "Anexo"), [125, 190, 240, 180], 12)
        holder.grid(row=2, column=0, sticky="nsew")
        frame.grid_rowconfigure(2, weight=1)
        barra = ctk.CTkFrame(frame, fg_color="transparent")
        barra.grid(row=3, column=0, sticky="ew", pady=12)
        novo_email = ctk.CTkEntry(barra, placeholder_text="Novo e-mail", width=280)
        novo_email.pack(side="left")
        cache = {}

        def carregar(*_):
            cache.clear()
            tree.delete(*tree.get_children())
            termo = busca.get().strip().lower()
            try:
                for cliente in self.clientes.listar():
                    if termo in "{} {} {}".format(cliente.cil, cliente.nome, cliente.email).lower():
                        item = tree.insert("", "end", values=(cliente.cil, cliente.nome, cliente.email, cliente.arquivo_anexo))
                        cache[item] = cliente
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        def atualizar_email():
            selecao = tree.selection()
            email = novo_email.get().strip()
            if not selecao or not EMAIL_RE.match(email):
                messagebox.showwarning("Validação", "Selecione um cliente e introduza um e-mail válido.")
                return
            cliente = cache[selecao[0]]
            try:
                self.clientes.atualizar(cliente.cil, Cliente(cliente.cil, cliente.nome, email, cliente.arquivo_anexo))
                carregar()
                novo_email.delete(0, "end")
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        def eliminar():
            selecao = tree.selection()
            if not selecao:
                return
            cliente = cache[selecao[0]]
            if messagebox.askyesno("Confirmar", "Eliminar o cliente {}?".format(cliente.cil)):
                try:
                    self.clientes.eliminar(cliente.cil)
                    carregar()
                except Exception as exc:
                    messagebox.showerror("Erro", str(exc))

        ctk.CTkButton(barra, text="Atualizar e-mail", command=atualizar_email).pack(side="left", padx=10)
        ctk.CTkButton(barra, text="Eliminar", command=eliminar).pack(side="left")
        busca.bind("<KeyRelease>", carregar)
        carregar()

    def pagina_envio(self):
        frame = self.pagina("Enviar E-mails", scroll=False)
        topo = ctk.CTkFrame(frame, fg_color=self.PANEL, corner_radius=12)
        topo.grid(row=1, column=0, sticky="ew")
        topo.grid_columnconfigure(0, weight=1)
        pasta = ctk.StringVar()
        ctk.CTkEntry(topo, textvariable=pasta, placeholder_text="Pasta dos ficheiros PDF", height=38).grid(row=0, column=0, padx=14, pady=14, sticky="ew")
        ctk.CTkButton(topo, text="Escolher pasta", command=lambda: pasta.set(filedialog.askdirectory())).grid(row=0, column=1, padx=(0, 14))
        progresso = ctk.CTkProgressBar(frame)
        progresso.grid(row=2, column=0, sticky="ew", pady=14)
        progresso.set(0)
        log = ctk.CTkTextbox(frame, height=390)
        log.grid(row=3, column=0, sticky="nsew")
        frame.grid_rowconfigure(3, weight=1)

        def executar():
            try:
                clientes = list(self.clientes.listar())
                corpo = self.conf.obter_corpo_email()
                destinatarios_cc = list(self.cc.listar())
            except Exception as exc:
                self.after(0, lambda: messagebox.showerror("Erro", str(exc)))
                return
            total = max(len(clientes), 1)
            for index, cliente in enumerate(clientes, 1):
                anexo = Path(pasta.get()) / (cliente.arquivo_anexo or "{}.pdf".format(cliente.cil))
                try:
                    self.email.enviar(cliente.email, cliente.nome, corpo, str(anexo), destinatarios_cc)
                    status, mensagem = "SUCESSO", "E-mail enviado com sucesso."
                except Exception as exc:
                    status, mensagem = "ERRO", str(exc)
                try:
                    self.relatorios.inserir(RelatorioEnvio(cliente.nome, cliente.email, cliente.cil, status, mensagem, datetime.now()))
                except Exception:
                    pass
                self.after(0, lambda c=cliente, s=status, m=mensagem, i=index: (
                    log.insert("end", "{} - {}: {}\n".format(c.cil, s, m)),
                    log.see("end"),
                    progresso.set(i / total),
                ))
            self.after(0, lambda: messagebox.showinfo("Concluído", "Processamento terminado."))

        def iniciar():
            if not Path(pasta.get()).is_dir():
                messagebox.showwarning("Pasta", "Selecione uma pasta válida.")
                return
            threading.Thread(target=executar, daemon=True).start()

        ctk.CTkButton(frame, text="Iniciar envio", width=140, command=iniciar).grid(row=4, column=0, sticky="e", pady=12)

    def pagina_corpo(self):
        frame = self.pagina("Corpo do E-mail", scroll=False)
        texto = ctk.CTkTextbox(frame, height=520)
        texto.grid(row=1, column=0, sticky="nsew")
        frame.grid_rowconfigure(1, weight=1)
        try:
            texto.insert("1.0", self.conf.obter_corpo_email())
        except Exception as exc:
            messagebox.showerror("Erro", str(exc))

        def guardar():
            try:
                self.conf.guardar_corpo_email(texto.get("1.0", "end-1c"))
                messagebox.showinfo("Sucesso", "Corpo do e-mail guardado.")
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        ctk.CTkButton(frame, text="Guardar", width=130, command=guardar).grid(row=2, column=0, sticky="e", pady=12)

    def pagina_cc(self):
        frame = self.pagina("Gestão de Destinatários CC", scroll=False)
        entrada = ctk.CTkEntry(frame, placeholder_text="email@dominio.cv", height=38)
        entrada.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        holder, tree = self._criar_tree(frame, ("E-mail CC",), [600], 13)
        holder.grid(row=2, column=0, sticky="nsew")
        frame.grid_rowconfigure(2, weight=1)
        barra = ctk.CTkFrame(frame, fg_color="transparent")
        barra.grid(row=3, column=0, sticky="e", pady=12)

        def carregar():
            tree.delete(*tree.get_children())
            try:
                for email in self.cc.listar():
                    tree.insert("", "end", values=(email,))
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        def adicionar():
            email = entrada.get().strip()
            if not EMAIL_RE.match(email):
                messagebox.showwarning("Validação", "E-mail inválido.")
                return
            try:
                self.cc.inserir(email)
                entrada.delete(0, "end")
                carregar()
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        def eliminar():
            selecao = tree.selection()
            email = tree.item(selecao[0], "values")[0] if selecao else entrada.get().strip()
            if not email:
                return
            try:
                self.cc.eliminar(email)
                carregar()
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        ctk.CTkButton(barra, text="Adicionar", command=adicionar).pack(side="left", padx=5)
        ctk.CTkButton(barra, text="Eliminar", command=eliminar).pack(side="left", padx=5)
        carregar()

    @staticmethod
    def _parse_data(valor):
        valor = valor.strip()
        if not valor:
            return None
        return datetime.strptime(valor, "%d/%m/%Y").date()

    def pagina_relatorios(self):
        frame = self.pagina("Relatório de Envios", scroll=False)
        filtros = ctk.CTkFrame(frame, fg_color="transparent")
        filtros.grid(row=1, column=0, sticky="w", pady=(0, 10))
        ctk.CTkLabel(filtros, text="Início:").pack(side="left", padx=(0, 6))
        inicio = ctk.CTkEntry(filtros, placeholder_text="dd/mm/aaaa", width=150)
        inicio.pack(side="left", padx=(0, 16))
        ctk.CTkLabel(filtros, text="Fim:").pack(side="left", padx=(0, 6))
        fim = ctk.CTkEntry(filtros, placeholder_text="dd/mm/aaaa", width=150)
        fim.pack(side="left", padx=(0, 16))
        holder, tree = self._criar_tree(frame, ("Data", "Nome", "Email", "CIL", "Status", "Mensagem"), [140, 150, 200, 100, 90, 310], 12)
        holder.grid(row=2, column=0, sticky="nsew")
        frame.grid_rowconfigure(2, weight=1)
        cache: List[RelatorioEnvio] = []

        def carregar():
            try:
                data_inicio = self._parse_data(inicio.get())
                data_fim = self._parse_data(fim.get())
            except ValueError:
                messagebox.showwarning("Data", "Utilize o formato dd/mm/aaaa.")
                return
            tree.delete(*tree.get_children())
            cache[:] = list(self.relatorios.listar(data_inicio, data_fim))
            for rel in cache:
                tree.insert("", "end", values=(rel.data_envio.strftime("%d/%m/%Y %H:%M"), rel.nome, rel.email, rel.cil, rel.status, rel.mensagem))

        ctk.CTkButton(filtros, text="Filtrar", command=carregar).pack(side="left")
        barra = ctk.CTkFrame(frame, fg_color="transparent")
        barra.grid(row=3, column=0, sticky="w", pady=12)

        def excel():
            caminho = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
            if caminho:
                exportar_excel(cache, caminho)
                messagebox.showinfo("Sucesso", "Relatório Excel exportado.")

        def pdf():
            caminho = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
            if caminho:
                exportar_pdf(cache, caminho)
                messagebox.showinfo("Sucesso", "Relatório PDF exportado.")

        ctk.CTkButton(barra, text="Exportar Excel", command=excel).pack(side="left", padx=(0, 10))
        ctk.CTkButton(barra, text="Exportar PDF", command=pdf).pack(side="left")
        carregar()

    def pagina_usuarios(self):
        frame = self.pagina("Gestão de Utilizadores", scroll=False)
        ctk.CTkLabel(frame, text="Crie e altere utilizadores, palavras-passe e níveis de acesso.").grid(row=1, column=0, sticky="w", pady=(0, 12))
        form = ctk.CTkFrame(frame, fg_color="transparent")
        form.grid(row=2, column=0, sticky="ew")
        form.grid_columnconfigure(1, weight=1)
        campos = {}
        for row, nome in enumerate(("Utilizador", "Palavra-passe", "Confirmar")):
            ctk.CTkLabel(form, text="{}:".format(nome)).grid(row=row, column=0, sticky="w", pady=6, padx=(0, 14))
            entrada = ctk.CTkEntry(form, show="•" if nome != "Utilizador" else "", height=36)
            entrada.grid(row=row, column=1, sticky="ew", pady=6)
            campos[nome] = entrada
        ctk.CTkLabel(form, text="Nível:").grid(row=3, column=0, sticky="w", pady=6)
        nivel = ctk.CTkComboBox(form, values=["admin", "gerente"], state="readonly", height=36)
        nivel.grid(row=3, column=1, sticky="ew", pady=6)
        nivel.set("gerente")
        mostrar = ctk.BooleanVar(value=False)

        def alternar():
            mascara = "" if mostrar.get() else "•"
            campos["Palavra-passe"].configure(show=mascara)
            campos["Confirmar"].configure(show=mascara)

        ctk.CTkCheckBox(form, text="Mostrar palavras-passe", variable=mostrar, command=alternar).grid(row=4, column=1, sticky="w", pady=6)
        botoes = ctk.CTkFrame(frame, fg_color="transparent")
        botoes.grid(row=3, column=0, sticky="w", pady=10)
        holder, tree = self._criar_tree(frame, ("ID", "Utilizador", "Palavra-passe", "Nível"), [80, 220, 220, 150], 9)
        holder.grid(row=4, column=0, sticky="nsew")
        frame.grid_rowconfigure(4, weight=1)
        cache = {}
        selecionado = {"id": None}

        def limpar():
            selecionado["id"] = None
            for entrada in campos.values():
                entrada.delete(0, "end")
            nivel.set("gerente")
            tree.selection_remove(tree.selection())

        def carregar():
            cache.clear()
            tree.delete(*tree.get_children())
            for usuario in self.usuarios.listar():
                item = tree.insert("", "end", values=(usuario.id, usuario.username, "•" * len(usuario.password), usuario.nivel))
                cache[item] = usuario

        def selecionar(_event=None):
            sel = tree.selection()
            if not sel:
                return
            usuario = cache[sel[0]]
            selecionado["id"] = usuario.id
            campos["Utilizador"].delete(0, "end")
            campos["Utilizador"].insert(0, usuario.username)
            campos["Palavra-passe"].delete(0, "end")
            campos["Palavra-passe"].insert(0, usuario.password)
            campos["Confirmar"].delete(0, "end")
            campos["Confirmar"].insert(0, usuario.password)
            nivel.set(usuario.nivel)

        def validar():
            if not campos["Utilizador"].get().strip():
                messagebox.showwarning("Validação", "Informe o utilizador.")
                return False
            if not campos["Palavra-passe"].get():
                messagebox.showwarning("Validação", "Informe a palavra-passe.")
                return False
            if campos["Palavra-passe"].get() != campos["Confirmar"].get():
                messagebox.showwarning("Validação", "As palavras-passe não coincidem.")
                return False
            return True

        def guardar():
            if not validar():
                return
            try:
                self.usuarios.inserir(campos["Utilizador"].get(), campos["Palavra-passe"].get(), nivel.get())
                carregar()
                limpar()
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        def alterar():
            if selecionado["id"] is None or not validar():
                messagebox.showwarning("Seleção", "Selecione um utilizador.")
                return
            try:
                self.usuarios.atualizar(selecionado["id"], campos["Utilizador"].get(), campos["Palavra-passe"].get(), nivel.get())
                carregar()
                limpar()
            except Exception as exc:
                messagebox.showerror("Erro", str(exc))

        def eliminar():
            if selecionado["id"] is None:
                return
            if selecionado["id"] == self.usuario.id:
                messagebox.showwarning("Operação", "Não pode eliminar o utilizador atualmente autenticado.")
                return
            if messagebox.askyesno("Confirmar", "Eliminar o utilizador selecionado?"):
                try:
                    self.usuarios.eliminar(selecionado["id"])
                    carregar()
                    limpar()
                except Exception as exc:
                    messagebox.showerror("Erro", str(exc))

        ctk.CTkButton(botoes, text="Novo", command=limpar).pack(side="left", padx=(0, 8))
        ctk.CTkButton(botoes, text="Guardar", command=guardar).pack(side="left", padx=8)
        ctk.CTkButton(botoes, text="Alterar", command=alterar).pack(side="left", padx=8)
        ctk.CTkButton(botoes, text="Eliminar", command=eliminar).pack(side="left", padx=8)
        ctk.CTkButton(botoes, text="Limpar", command=limpar).pack(side="left", padx=8)
        tree.bind("<<TreeviewSelect>>", selecionar)
        carregar()

    def pagina_definicoes(self):
        frame = self.pagina("Definições")
        ctk.CTkLabel(
            frame,
            text="As ligações à base de dados e ao SMTP são configuradas no ficheiro config.ini.",
            font=ctk.CTkFont(size=15),
        ).grid(row=1, column=0, sticky="w")
