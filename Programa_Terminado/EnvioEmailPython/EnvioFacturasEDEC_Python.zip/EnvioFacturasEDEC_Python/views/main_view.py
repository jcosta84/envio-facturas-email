import customtkinter as ctk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import datetime
import threading, re
from models.entities import Cliente, RelatorioEnvio
from database.repositories import ClienteRepository,CcRepository,ConfiguracaoRepository,RelatorioRepository,UsuarioRepository,AuditoriaRepository
from services.email_service import EmailService
from services.export_service import exportar_excel,exportar_pdf

EMAIL_RE=re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')

class MainView(ctk.CTk):
    def __init__(self,config,db,usuario):
        super().__init__(); self.config_service=config; self.db=db; self.usuario=usuario
        self.clientes=ClienteRepository(db); self.cc=CcRepository(db); self.conf=ConfiguracaoRepository(db); self.relatorios=RelatorioRepository(db); self.usuarios=UsuarioRepository(db); self.aud=AuditoriaRepository(db); self.email=EmailService(config)
        self.title('Gestão e Envio de E-mails'); self.geometry('1280x800'); self.minsize(1050,680)
        self.grid_columnconfigure(1,weight=1); self.grid_rowconfigure(0,weight=1)
        self.sidebar=ctk.CTkFrame(self,width=230,corner_radius=0); self.sidebar.grid(row=0,column=0,sticky='nsew'); self.sidebar.grid_propagate(False)
        self.content=ctk.CTkFrame(self,corner_radius=0); self.content.grid(row=0,column=1,sticky='nsew'); self.content.grid_columnconfigure(0,weight=1); self.content.grid_rowconfigure(0,weight=1)
        ctk.CTkLabel(self.sidebar,text=self.usuario.username,font=ctk.CTkFont(size=20,weight='bold')).pack(pady=(28,2)); ctk.CTkLabel(self.sidebar,text=self.usuario.nivel.upper()).pack(pady=(0,18))
        botoes=[('Início',self.pagina_inicio),('Clientes',self.pagina_clientes),('Consulta',self.pagina_consulta),('Enviar E-mails',self.pagina_envio),('Corpo do E-mail',self.pagina_corpo),('Gerir CC',self.pagina_cc),('Relatórios',self.pagina_relatorios)]
        if usuario.is_admin: botoes.append(('Utilizadores',self.pagina_usuarios))
        if usuario.is_gerente: botoes.append(('Definições',self.pagina_definicoes))
        for texto,cmd in botoes: ctk.CTkButton(self.sidebar,text=texto,anchor='w',command=cmd).pack(fill='x',padx=16,pady=5)
        ctk.CTkButton(self.sidebar,text='Sair',fg_color='transparent',border_width=1,command=self.destroy).pack(side='bottom',fill='x',padx=16,pady=20)
        self.pagina_inicio()
    def limpar(self):
        for w in self.content.winfo_children(): w.destroy()
    def pagina(self,titulo):
        self.limpar(); f=ctk.CTkScrollableFrame(self.content); f.grid(row=0,column=0,sticky='nsew',padx=18,pady=18); f.grid_columnconfigure(0,weight=1); ctk.CTkLabel(f,text=titulo,font=ctk.CTkFont(size=28,weight='bold')).grid(row=0,column=0,sticky='w',pady=(4,20)); return f
    def pagina_inicio(self):
        f=self.pagina('Início'); ctk.CTkLabel(f,text='Bem-vindo ao sistema de gestão de clientes e envio de facturas.',font=ctk.CTkFont(size=18)).grid(row=1,column=0,sticky='w')
    def _form_cliente(self,f):
        campos={}; labels=['CIL','Nome','E-mail','Arquivo anexo']
        for i,l in enumerate(labels,1): ctk.CTkLabel(f,text=l).grid(row=i,column=0,sticky='w',padx=8,pady=6); campos[l]=ctk.CTkEntry(f,width=450); campos[l].grid(row=i,column=1,sticky='ew',padx=8,pady=6)
        return campos
    def pagina_clientes(self):
        f=self.pagina('Cadastro de Clientes'); f.grid_columnconfigure(1,weight=1); c=self._form_cliente(f)
        def guardar():
            cli=Cliente(c['CIL'].get().strip(),c['Nome'].get().strip(),c['E-mail'].get().strip(),c['Arquivo anexo'].get().strip())
            if not cli.cil or not cli.nome or not EMAIL_RE.match(cli.email): messagebox.showwarning('Validação','Preencha CIL, nome e um e-mail válido.'); return
            try:self.clientes.inserir(cli); self.aud.log(self.usuario.id,'INSERIR','Clientes',f'Cliente {cli.cil} inserido.'); messagebox.showinfo('Sucesso','Cliente guardado.')
            except Exception as e:messagebox.showerror('Erro',str(e))
        ctk.CTkButton(f,text='Guardar',command=guardar).grid(row=5,column=1,sticky='e',padx=8,pady=15)
    def _tree(self,parent,colunas):
        tree=ttk.Treeview(parent,columns=colunas,show='headings',height=18)
        for c in colunas: tree.heading(c,text=c); tree.column(c,width=140,anchor='w')
        tree.grid(sticky='nsew',padx=8,pady=8); return tree
    def pagina_consulta(self):
        f=self.pagina('Consulta de Clientes'); busca=ctk.CTkEntry(f,placeholder_text='Pesquisar por CIL, nome ou e-mail'); busca.grid(row=1,column=0,sticky='ew',padx=8)
        holder=ctk.CTkFrame(f); holder.grid(row=2,column=0,sticky='nsew',pady=10); tree=self._tree(holder,('CIL','Nome','E-mail','Anexo'))
        def carregar(*_):
            for x in tree.get_children(): tree.delete(x)
            termo=busca.get().lower()
            try:
                for c in self.clientes.listar():
                    if termo in f'{c.cil} {c.nome} {c.email}'.lower(): tree.insert('', 'end',values=(c.cil,c.nome,c.email,c.arquivo_anexo))
            except Exception as e: messagebox.showerror('Erro',str(e))
        busca.bind('<KeyRelease>',carregar)
        def eliminar():
            s=tree.selection();
            if not s:return
            cil=tree.item(s[0])['values'][0]
            if messagebox.askyesno('Confirmar',f'Eliminar o cliente {cil}?'):
                try:self.clientes.eliminar(str(cil)); carregar()
                except Exception as e:messagebox.showerror('Erro',str(e))
        ctk.CTkButton(f,text='Eliminar selecionado',command=eliminar).grid(row=3,column=0,sticky='e',padx=8); carregar()
    def pagina_corpo(self):
        f=self.pagina('Corpo do E-mail'); txt=ctk.CTkTextbox(f,height=430); txt.grid(row=1,column=0,sticky='nsew',padx=8)
        try:txt.insert('1.0',self.conf.obter_corpo_email())
        except Exception as e:messagebox.showerror('Erro',str(e))
        def guardar():
            try:self.conf.guardar_corpo_email(txt.get('1.0','end-1c')); messagebox.showinfo('Sucesso','Corpo do e-mail guardado.')
            except Exception as e:messagebox.showerror('Erro',str(e))
        ctk.CTkButton(f,text='Guardar',command=guardar).grid(row=2,column=0,sticky='e',padx=8,pady=10)
    def pagina_cc(self):
        f=self.pagina('Gerir CC'); ent=ctk.CTkEntry(f,placeholder_text='email@dominio.cv'); ent.grid(row=1,column=0,sticky='ew',padx=8); lista=ctk.CTkTextbox(f,height=360); lista.grid(row=2,column=0,sticky='nsew',padx=8,pady=10)
        def carregar():
            lista.delete('1.0','end')
            try: lista.insert('1.0','\n'.join(self.cc.listar()))
            except Exception as e:messagebox.showerror('Erro',str(e))
        def add():
            if not EMAIL_RE.match(ent.get().strip()):messagebox.showwarning('Validação','E-mail inválido.');return
            try:self.cc.inserir(ent.get()); ent.delete(0,'end'); carregar()
            except Exception as e:messagebox.showerror('Erro',str(e))
        def rem():
            try:self.cc.eliminar(ent.get()); carregar()
            except Exception as e:messagebox.showerror('Erro',str(e))
        bar=ctk.CTkFrame(f); bar.grid(row=3,column=0,sticky='e'); ctk.CTkButton(bar,text='Adicionar',command=add).pack(side='left',padx=5); ctk.CTkButton(bar,text='Eliminar',command=rem).pack(side='left',padx=5); carregar()
    def pagina_envio(self):
        f=self.pagina('Enviar E-mails'); pasta=ctk.StringVar(); ctk.CTkEntry(f,textvariable=pasta).grid(row=1,column=0,sticky='ew',padx=8); ctk.CTkButton(f,text='Escolher pasta',command=lambda:pasta.set(filedialog.askdirectory())).grid(row=1,column=1,padx=8)
        progresso=ctk.CTkProgressBar(f); progresso.grid(row=2,column=0,columnspan=2,sticky='ew',padx=8,pady=12); progresso.set(0); log=ctk.CTkTextbox(f,height=360); log.grid(row=3,column=0,columnspan=2,sticky='nsew',padx=8)
        def iniciar():
            if not Path(pasta.get()).is_dir(): messagebox.showwarning('Pasta','Selecione uma pasta válida.'); return
            threading.Thread(target=executar,daemon=True).start()
        def executar():
            try: clientes=list(self.clientes.listar()); corpo=self.conf.obter_corpo_email(); cc=list(self.cc.listar())
            except Exception as e:self.after(0,lambda:messagebox.showerror('Erro',str(e)));return
            total=max(len(clientes),1)
            for i,c in enumerate(clientes,1):
                anexo=Path(pasta.get())/(c.arquivo_anexo or f'{c.cil}.pdf')
                try:self.email.enviar(c.email,c.nome,corpo,str(anexo),cc); status='ENVIADO'; msg='Enviado com sucesso.'
                except Exception as e:status='ERRO'; msg=str(e)
                try:self.relatorios.inserir(RelatorioEnvio(c.nome,c.email,c.cil,status,msg,datetime.now()))
                except:pass
                self.after(0,lambda c=c,status=status,msg=msg,i=i: (log.insert('end',f'{c.cil} - {status}: {msg}\n'),log.see('end'),progresso.set(i/total)))
            self.after(0,lambda:messagebox.showinfo('Concluído','Processamento terminado.'))
        ctk.CTkButton(f,text='Iniciar envio',command=iniciar).grid(row=4,column=1,sticky='e',padx=8,pady=10)
    def pagina_relatorios(self):
        f=self.pagina('Relatórios'); holder=ctk.CTkFrame(f); holder.grid(row=1,column=0,sticky='nsew'); tree=self._tree(holder,('Nome','E-mail','CIL','Status','Mensagem','Data')); cache=[]
        def carregar():
            cache.clear();
            for x in tree.get_children():tree.delete(x)
            try:
                for r in self.relatorios.listar(): cache.append(r); tree.insert('', 'end',values=(r.nome,r.email,r.cil,r.status,r.mensagem,r.data_envio.strftime('%d/%m/%Y %H:%M')))
            except Exception as e:messagebox.showerror('Erro',str(e))
        def ex_excel():
            p=filedialog.asksaveasfilename(defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')]);
            if p: exportar_excel(cache,p)
        def ex_pdf():
            p=filedialog.asksaveasfilename(defaultextension='.pdf',filetypes=[('PDF','*.pdf')]);
            if p: exportar_pdf(cache,p)
        bar=ctk.CTkFrame(f); bar.grid(row=2,column=0,sticky='e'); ctk.CTkButton(bar,text='Excel',command=ex_excel).pack(side='left',padx=5); ctk.CTkButton(bar,text='PDF',command=ex_pdf).pack(side='left',padx=5); carregar()
    def pagina_usuarios(self):
        f=self.pagina('Gestão de Utilizadores'); campos={}
        for i,(k,show) in enumerate([('Utilizador',''),('Palavra-passe','•')],1): ctk.CTkLabel(f,text=k).grid(row=i,column=0); campos[k]=ctk.CTkEntry(f,show=show); campos[k].grid(row=i,column=1,padx=8,pady=5)
        nivel=ctk.CTkComboBox(f,values=['admin','gerente']); nivel.grid(row=3,column=1,padx=8,pady=5)
        def add():
            try:self.usuarios.inserir(campos['Utilizador'].get(),campos['Palavra-passe'].get(),nivel.get());messagebox.showinfo('Sucesso','Utilizador criado.')
            except Exception as e:messagebox.showerror('Erro',str(e))
        ctk.CTkButton(f,text='Criar utilizador',command=add).grid(row=4,column=1,sticky='e',pady=10)
    def pagina_definicoes(self):
        f=self.pagina('Definições'); ctk.CTkLabel(f,text='As ligações à base de dados e ao SMTP são configuradas no ficheiro config.ini.').grid(row=1,column=0,sticky='w')
