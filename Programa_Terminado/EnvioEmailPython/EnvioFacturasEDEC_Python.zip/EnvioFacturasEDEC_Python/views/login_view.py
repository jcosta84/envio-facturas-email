import customtkinter as ctk
from tkinter import messagebox
from services.config_service import ConfigService
from database.connection import Database
from database.repositories import UsuarioRepository

ctk.set_appearance_mode('system'); ctk.set_default_color_theme('blue')

class LoginView(ctk.CTk):
    def __init__(self):
        super().__init__(); self.title('EDEC SUL - Login'); self.geometry('900x560'); self.resizable(False,False)
        try:
            self.config_service=ConfigService(); self.db=Database(self.config_service); self.db.testar(); self.repo=UsuarioRepository(self.db)
        except Exception as e:
            messagebox.showerror('Erro de inicialização',str(e)); self.after(100,self.destroy); return
        self.grid_columnconfigure((0,1),weight=1); self.grid_rowconfigure(0,weight=1)
        left=ctk.CTkFrame(self,corner_radius=0); left.grid(row=0,column=0,sticky='nsew');
        ctk.CTkLabel(left,text='EDEC SUL',font=ctk.CTkFont(size=34,weight='bold')).pack(pady=(140,10))
        ctk.CTkLabel(left,text='Sistema de Gestão e Envio de Facturas',font=ctk.CTkFont(size=17)).pack()
        box=ctk.CTkFrame(self); box.grid(row=0,column=1,padx=60,pady=80,sticky='nsew')
        ctk.CTkLabel(box,text='Iniciar sessão',font=ctk.CTkFont(size=26,weight='bold')).pack(pady=(55,25))
        self.user=ctk.CTkEntry(box,placeholder_text='Utilizador',width=280); self.user.pack(pady=8)
        self.pwd=ctk.CTkEntry(box,placeholder_text='Palavra-passe',show='•',width=280); self.pwd.pack(pady=8)
        self.msg=ctk.CTkLabel(box,text=''); self.msg.pack(pady=6)
        ctk.CTkButton(box,text='Entrar',width=280,command=self.entrar).pack(pady=15)
        self.bind('<Return>',lambda e:self.entrar())
    def entrar(self):
        try: u=self.repo.autenticar(self.user.get(),self.pwd.get())
        except Exception as e: messagebox.showerror('Erro',str(e)); return
        if not u: self.msg.configure(text='Dados inválidos ou conta indisponível.'); return
        self.withdraw(); from views.main_view import MainView; app=MainView(self.config_service,self.db,u); app.protocol('WM_DELETE_WINDOW',self.destroy); app.mainloop(); self.destroy()
