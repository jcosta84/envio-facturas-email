from email.message import EmailMessage
from pathlib import Path
import mimetypes, smtplib

class EmailService:
    def __init__(self, config): self.config=config
    def enviar(self,destinatario,nome,corpo,anexo,cc=()):
        msg=EmailMessage(); remetente=self.config.get('EMAIL','REMETENTE'); nome_rem=self.config.get('EMAIL','NOME_REMETENTE','EDEC SUL')
        msg['From']=f"{nome_rem} <{remetente}>"; msg['To']=destinatario; msg['Subject']=self.config.get('EMAIL','ASSUNTO')
        if cc: msg['Cc']=', '.join(cc)
        msg.set_content(corpo.replace('{NOME}',nome))
        p=Path(anexo)
        if p.is_file():
            tipo,_=mimetypes.guess_type(p.name); principal,sub=(tipo or 'application/octet-stream').split('/',1)
            msg.add_attachment(p.read_bytes(),maintype=principal,subtype=sub,filename=p.name)
        host=self.config.get('EMAIL','SMTP_HOST'); porta=self.config.getint('EMAIL','SMTP_PORT'); seguranca=self.config.get('EMAIL','SMTP_SEGURANCA').upper()
        user=self.config.get('EMAIL','USERNAME'); pwd=self.config.get('EMAIL','PASSWORD')
        smtp = smtplib.SMTP_SSL(host,porta,timeout=30) if seguranca=='SSL' else smtplib.SMTP(host,porta,timeout=30)
        try:
            smtp.ehlo()
            if seguranca=='STARTTLS': smtp.starttls(); smtp.ehlo()
            smtp.login(user,pwd); smtp.send_message(msg)
        finally: smtp.quit()
