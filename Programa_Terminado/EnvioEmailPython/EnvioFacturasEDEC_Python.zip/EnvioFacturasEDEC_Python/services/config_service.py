from configparser import ConfigParser
from pathlib import Path
import sys

class ConfigService:
    def __init__(self, caminho: str | None = None):
        base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
        candidatos = [Path(caminho)] if caminho else [Path.cwd()/"config.ini", base/"config.ini"]
        self.path = next((p for p in candidatos if p and p.exists()), None)
        if not self.path:
            raise FileNotFoundError("config.ini não encontrado.")
        self.config = ConfigParser()
        self.config.read(self.path, encoding="utf-8")
        self._validar()

    def _validar(self):
        obrigatorios = {
            "DATABASE": ["HOST","PORT","DATABASE","USERNAME","PASSWORD"],
            "EMAIL": ["REMETENTE","USERNAME","PASSWORD","ASSUNTO","SMTP_HOST","SMTP_PORT","SMTP_SEGURANCA"]
        }
        for secao, chaves in obrigatorios.items():
            for chave in chaves:
                if not self.get(secao, chave):
                    raise ValueError(f"Configuração obrigatória vazia: [{secao}] {chave}")

    def get(self, secao: str, chave: str, fallback: str = "") -> str:
        return self.config.get(secao, chave, fallback=fallback).strip()
    def getint(self, secao: str, chave: str) -> int:
        return self.config.getint(secao, chave)
